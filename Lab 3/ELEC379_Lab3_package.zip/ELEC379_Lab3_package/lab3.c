#include <stdlib.h>
#include <stdio.h>
#include "graph.h"

#define CREATE(NUM, TYPE) (TYPE *) calloc(NUM, sizeof(TYPE))

/* declaration of function in library */

void DFS (Graph *g, int s);


/* fill in this function with the specified processing on the graph
   after the search has been performed */

void GraphProcessing (Graph *g, int s)
{
   int i;
   Edge *p;

   printf("Graph has %d vertices and %d edges.\n", g->num_vertices, g->num_edges);
   printf("Graph is type %d\n", g->type);
   printf("List of Edges:\n");

   for(i = 0; i < g->num_vertices; i++){
      printf("%d: d = %d, f = %d, pred = %d\n",g->v[i].adj->vertex, g->v[i].d, g->v[i].f, g->v[i].pred);
   }
   printf("(%d)", s);
}

void PrintGraph(Graph *g, int show_duplicates){
   int i;
   Edge *p;

   printf("Graph has %d vertices and %d edges.\n", g->num_vertices, g->num_edges);
   printf("Graph is type %d\n", g->type);
   printf("List of Edges:\n");

   for(i = 0; i < g->num_vertices; i++){
      for (p = g->v[i].adj; p != NULL; p = p->next){ //Adj List
      if(g->type == UNDIRECTED && show_duplicates == 0 && p->other_vertex < p->vertex){
         continue;
      }else{
         printf("  (%d, %d) %d\n",p->vertex, p->other_vertex, p->weight);
      }

      }
   }
}

/* main routine that reads in text file describing a graph
   then performs search and subsequent processing */

int main (int argc, char *argv[])
{
   Graph *g;
   Vertex *v;
   int s;
  
   if (argc != 3)
   {
      printf ("usage: %s <graph_file> <source_vertex>\n", argv[0]);
      return 1;
   }
   
   g = CREATE(1, Graph);
   g->type = UNDIRECTED;
   g->num_vertices = 3;
   g->num_edges = 3;

	v = CREATE(g->num_vertices, Vertex);
	g->v = v;
	
	Edge *e1 = CREATE(1, Edge);
	Edge *e2 = CREATE(1, Edge);
	Edge *e3 = CREATE(1, Edge);
	Edge *e4 = CREATE(1, Edge);
	Edge *e5 = CREATE(1, Edge);
	Edge *e6 = CREATE(1, Edge);
	e1->vertex = 0;
	e1->other_vertex = 1;
	e1->next = e4;
	e1->weight = e1->vertex + e1->other_vertex;
	e4->vertex = 0;
	e4->other_vertex = 2;
	e4->next = NULL;
	e4->weight = e4->vertex + e4->other_vertex;
	
	e2->vertex = 1;
	e2->other_vertex = 2;
	e2->next = e5;
	e2->weight = e2->vertex + e2->other_vertex;
	e5->vertex = 1;
	e5->other_vertex = 0;
	e5->next = NULL;
	e5->weight = e5->vertex + e5->other_vertex;
	
	e3->vertex = 2;
	e3->other_vertex = 0;
	e3->next = e6;
	e3->weight = e3->vertex + e3->other_vertex;
	e6->vertex = 2;
	e6->other_vertex = 1;
	e6->next = NULL;
	e6->weight = e6->vertex + e6->other_vertex;
	
	g->v[0].adj = e1;
	g->v[1].adj = e2;
	g->v[2].adj = e3;
	
	g = ReadGraphFile (argv[1]);

   if (g != NULL)
   {
      s = atoi (argv[2]);
      if (s < 0 || s > g->num_vertices - 1)
      {
         printf ("source vertex ID must be between 0 and %d\n",
		 g->num_vertices - 1);
	 return 1;
      }

      DFS (g, s);

      GraphProcessing (g, s);
	  
	  //PrintGraph(g, 0);
   }

   return 0;
}

